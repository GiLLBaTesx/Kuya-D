<!DOCTYPE html>
<html lang="en">
<head>
    <title>Shoping Cart</title>
    <link rel="stylesheet" href="style1.css">
    <script src="js/bootstrap.js"></script>
    <style>
        body{
            background-color:  #ffe4b4;
        }
    </style>
</head>
<body>
    <div class="container">
        <header>
            <div class="d-flex flex-column flex-md-row align-items-center pb-3 mb-4 border-bottom">
                <a href="products.php" class="d-flex align-items-center text-dark text-decoration-none">
                    <span class="fs-4">Kuya D Specialties</span>
                </a>

                <nav class="d-inline-flex mt-md-0 ms-md-auto">
                    <a class="me-3 py-2 text-dark text-decoration-none btn btn-primary btn-sm" href="index1.html">Home</a>
                    <a class="me-3 py-2 text-light text-decoration-none btn btn-primary btn-sm" href="viewCart.php">View Cart</a>
                    <a class="me-3 py-2 text-light text-decoration-none btn btn-primary btn-sm" href="products.php">Back</a>
                </nav>
            </div>
        </header>
        <div class="row">
            <h1 class="text-center border-bottom pb-4 mb-4">Specialties</h1>
            <?php
                if(isset($_GET['true']) == "created"){
            ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <strong>Successfully!</strong> Your product added to Cart.
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php
                }
            ?>
        </div>
        <main>
            <div class="row row-cols-1 row-cols-md-3 mb-3 text-center">
            <div class="col">
                <div class="card mb-4 rounded-3 shadow-sm">
                <div class="card-header py-3">
                    <h4 class="my-0 fw-normal">Specialty 1</h4>
                </div>
                <div class="card-body">
                    <h1 class="card-title">Bagnet</h1>
                    <ul class="list-unstyled mt-3 mb-4">
                        <li><img src="Bagnet.jpg" alt="pandesal" style="width:70%;height:250px;"></li>
                        <li>Price: ₱95.00</li>
                    </ul>
                    <form action="addCart.php" method="post">
                        <input type="hidden" name="name" value="Bagnet">
                        <input type="hidden" name="price" value="95.00">
                        <input type="text" name="qty" placeholder="Quantity" required class="form-control">
                        <input type="submit" class="btn btn-lg btn-primary" value="Add to Cart">
                    </form>
                </div>
                </div>
            </div>

            <div class="col">
                <div class="card mb-4 rounded-3 shadow-sm">
                <div class="card-header py-3">
                    <h4 class="my-0 fw-normal">Specialty 2</h4>
                </div>
                <div class="card-body">
                    <h1 class="card-title">Fried Bangus</h1>
                    <ul class="list-unstyled mt-3 mb-4">
                        <li><img src="Bangus.jpg" alt="ensaymada" style="width:70%;height:250px;"></li>
                        <li>Price: ₱85.00</li>
                    </ul>
                    <form action="addCart.php" method="post">
                        <input type="hidden" name="name" value="Fried Bangus">
                        <input type="hidden" name="price" value="85.00">
                        <input type="text" name="qty" placeholder="Quantity" class="form-control">
                        <input type="submit" class="btn btn-lg btn-primary" value="Add to Cart">
                    </form>
                </div>
                </div>
            </div>

            <div class="col">
                <div class="card mb-4 rounded-3 shadow-sm">
                <div class="card-header py-3">
                    <h4 class="my-0 fw-normal">Specialty 3</h4>
                </div>
                <div class="card-body">
                    <h1 class="card-title">Burger Steak</h1>
                    <ul class="list-unstyled mt-3 mb-4">
                        <li><img src="Burger Steak.jpg" alt="kababayan" style="width:70%;height:250px;"></li>
                        <li>Price: ₱100.00</li>
                    </ul>
                    <form action="addCart.php" method="post">
                        <input type="hidden" name="name" value="Burger Steak">
                        <input type="hidden" name="price" value="100.00">
                        <input type="text" name="qty" placeholder="Quantity" class="form-control">
                        <input type="submit" class="btn btn-lg btn-primary" value="Add to Cart">
                    </form>
                </div>
                </div>
            </div>
            
            <div class="col">
                <div class="card mb-4 rounded-3 shadow-sm">
                <div class="card-header py-3">
                    <h4 class="my-0 fw-normal">Specialty 4</h4>
                </div>
                <div class="card-body">
                    <h1 class="card-title">Cameron Rebusado</h1>
                    <ul class="list-unstyled mt-3 mb-4">
                        <li><img src="Cameron Rebusado.jpg" alt="spanishbread" style="width:70%;height:250px;"></li>
                        <li>Price: ₱160.00</li>
                    </ul>
                    <form action="addCart.php" method="post">
                        <input type="hidden" name="name" value="Cameron Rebusado">
                        <input type="hidden" name="price" value="160.00">
                        <input type="text" name="qty" placeholder="Quantity" required class="form-control">
                        <input type="submit" class="btn btn-lg btn-primary" value="Add to Cart">
                    </form>
                </div>
                </div>
            </div>

            <div class="col">
                <div class="card mb-4 rounded-3 shadow-sm">
                <div class="card-header py-3">
                    <h4 class="my-0 fw-normal">Specialty 5</h4>
                </div>
                <div class="card-body">
                    <h1 class="card-title">Chicken-Butt</h1>
                    <ul class="list-unstyled mt-3 mb-4">
                        <li><img src="Chicken-Butt.jpg" alt="pineapplepie" style="width:70%;height:250px;"></li>
                        <li>Price: ₱80.00</li>
                    </ul>
                    <form action="addCart.php" method="post">
                        <input type="hidden" name="name" value="Chicken-Butt">
                        <input type="hidden" name="price" value="80.00">
                        <input type="text" name="qty" placeholder="Quantity" required class="form-control">
                        <input type="submit" class="btn btn-lg btn-primary" value="Add to Cart">
                    </form>
                </div>
                </div>
            </div>

            <div class="col">
                <div class="card mb-4 rounded-3 shadow-sm">
                <div class="card-header py-3">
                    <h4 class="my-0 fw-normal">Specialty 6</h4>
                </div>
                <div class="card-body">
                    <h1 class="card-title">Chicken</h1>
                    <ul class="list-unstyled mt-3 mb-4">
                        <li><img src="Chicken.jpg" alt="eggpie" style="width:70%;height:250px;"></li>
                        <li>Price: ₱139.00</li>
                    </ul>
                    <form action="addCart.php" method="post">
                        <input type="hidden" name="name" value="Chicken">
                        <input type="hidden" name="price" value="139.00">
                        <input type="text" name="qty" placeholder="Quantity" required class="form-control">
                        <input type="submit" class="btn btn-lg btn-primary" value="Add to Cart">
                    </form>
                </div>
                </div>
            </div>

            <div class="col">
                <div class="card mb-4 rounded-3 shadow-sm">
                <div class="card-header py-3">
                    <h4 class="my-0 fw-normal">Specialty 7</h4>
                </div>
                <div class="card-body">
                    <h1 class="card-title">Cochinillo</h1>
                    <ul class="list-unstyled mt-3 mb-4">
                        <li><img src="Cochinillo.jpg" alt="crinkles" style="width:70%;height:250px;"></li>
                        <li>Price: ₱250.00</li>
                    </ul>
                    <form action="addCart.php" method="post">
                        <input type="hidden" name="name" value="Cochinillo">
                        <input type="hidden" name="price" value="250.00">
                        <input type="text" name="qty" placeholder="Quantity" required class="form-control">
                        <input type="submit" class="btn btn-lg btn-primary" value="Add to Cart">
                    </form>
                </div>
                </div>
            </div>

            <div class="col">
                <div class="card mb-4 rounded-3 shadow-sm">
                <div class="card-header py-3">
                    <h4 class="my-0 fw-normal">Specialty 8</h4>
                </div>
                <div class="card-body">
                    <h1 class="card-title">Cornedbeef</h1>
                    <ul class="list-unstyled mt-3 mb-4">
                        <li><img src="Cornedbeef.jpg" alt="eggtart" style="width:70%;height:250px;"></li>
                        <li>Price: ₱60.00</li>
                    </ul>
                    <form action="addCart.php" method="post">
                        <input type="hidden" name="name" value="Cornedbeef">
                        <input type="hidden" name="price" value="60.00">
                        <input type="text" name="qty" placeholder="Quantity" required class="form-control">
                        <input type="submit" class="btn btn-lg btn-primary" value="Add to Cart">
                    </form>
                </div>
                </div>
            </div>

            <div class="col">
                <div class="card mb-4 rounded-3 shadow-sm">
                <div class="card-header py-3">
                    <h4 class="my-0 fw-normal">Specialty 9</h4>
                </div>
                <div class="card-body">
                    <h1 class="card-title">Grande-Lechon</h1>
                    <ul class="list-unstyled mt-3 mb-4">
                        <li><img src="Grande-Lechon.jpg" alt="eggtart" style="width:70%;height:250px;"></li>
                        <li>Price: ₱350.00</li>
                    </ul>
                    <form action="addCart.php" method="post">
                        <input type="hidden" name="name" value="Grande-Lechon">
                        <input type="hidden" name="price" value="350.00">
                        <input type="text" name="qty" placeholder="Quantity" required class="form-control">
                        <input type="submit" class="btn btn-lg btn-primary" value="Add to Cart">
                    </form>
                </div>
                </div>
            </div>

            <div class="col">
                <div class="card mb-4 rounded-3 shadow-sm">
                <div class="card-header py-3">
                    <h4 class="my-0 fw-normal">Specialty 10</h4>
                </div>
                <div class="card-body">
                    <h1 class="card-title">Hotsilog</h1>
                    <ul class="list-unstyled mt-3 mb-4">
                        <li><img src="Hot.jpg" alt="eggtart" style="width:70%;height:250px;"></li>
                        <li>Price: ₱55.00</li>
                    </ul>
                    <form action="addCart.php" method="post">
                        <input type="hidden" name="name" value="Hotsilog">
                        <input type="hidden" name="price" value="55.00">
                        <input type="text" name="qty" placeholder="Quantity" required class="form-control">
                        <input type="submit" class="btn btn-lg btn-primary" value="Add to Cart">
                    </form>
                </div>
                </div>
            </div>

            <div class="col">
                <div class="card mb-4 rounded-3 shadow-sm">
                <div class="card-header py-3">
                    <h4 class="my-0 fw-normal">Specialty 11</h4>
                </div>
                <div class="card-body">
                    <h1 class="card-title">Hungarian</h1>
                    <ul class="list-unstyled mt-3 mb-4">
                        <li><img src="Hungarian.jpg" alt="eggtart" style="width:70%;height:250px;"></li>
                        <li>Price: ₱80.00</li>
                    </ul>
                    <form action="addCart.php" method="post">
                        <input type="hidden" name="name" value="Hungarian">
                        <input type="hidden" name="price" value="80.00">
                        <input type="text" name="qty" placeholder="Quantity" required class="form-control">
                        <input type="submit" class="btn btn-lg btn-primary" value="Add to Cart">
                    </form>
                </div>
                </div>
            </div>

            <div class="col">
                <div class="card mb-4 rounded-3 shadow-sm">
                <div class="card-header py-3">
                    <h4 class="my-0 fw-normal">Specialty 12</h4>
                </div>
                <div class="card-body">
                    <h1 class="card-title">Krispy-Ulo</h1>
                    <ul class="list-unstyled mt-3 mb-4">
                        <li><img src="Krispy-Ulo.jpg" alt="eggtart" style="width:70%;height:250px;"></li>
                        <li>Price: ₱600.00</li>
                    </ul>
                    <form action="addCart.php" method="post">
                        <input type="hidden" name="name" value="Krispy-Ulo">
                        <input type="hidden" name="price" value="600.00">
                        <input type="text" name="qty" placeholder="Quantity" required class="form-control">
                        <input type="submit" class="btn btn-lg btn-primary" value="Add to Cart">
                    </form>
                </div>
                </div>
            </div>

            <div class="col">
                <div class="card mb-4 rounded-3 shadow-sm">
                <div class="card-header py-3">
                    <h4 class="my-0 fw-normal">Specialty 13</h4>
                </div>
                <div class="card-body">
                    <h1 class="card-title">Liemposilog</h1>
                    <ul class="list-unstyled mt-3 mb-4">
                        <li><img src="Liempo.jpg" alt="eggtart" style="width:70%;height:250px;"></li>
                        <li>Price: ₱95.00</li>
                    </ul>
                    <form action="addCart.php" method="post">
                        <input type="hidden" name="name" value="Liemposilog">
                        <input type="hidden" name="price" value="95.00">
                        <input type="text" name="qty" placeholder="Quantity" required class="form-control">
                        <input type="submit" class="btn btn-lg btn-primary" value="Add to Cart">
                    </form>
                </div>
                </div>
            </div>
            <div class="col">
                <div class="card mb-4 rounded-3 shadow-sm">
                <div class="card-header py-3">
                    <h4 class="my-0 fw-normal">Specialty 14</h4>
                </div>
                <div class="card-body">
                    <h1 class="card-title">Malingsilog</h1>
                    <ul class="list-unstyled mt-3 mb-4">
                        <li><img src="Maling.jpg" alt="eggtart" style="width:70%;height:250px;"></li>
                        <li>Price: ₱55.00</li>
                    </ul>
                    <form action="addCart.php" method="post">
                        <input type="hidden" name="name" value="Malingsilog">
                        <input type="hidden" name="price" value="55.00">
                        <input type="text" name="qty" placeholder="Quantity" required class="form-control">
                        <input type="submit" class="btn btn-lg btn-primary" value="Add to Cart">
                    </form>
                </div>
                </div>
            </div>

            <div class="col">
                <div class="card mb-4 rounded-3 shadow-sm">
                <div class="card-header py-3">
                    <h4 class="my-0 fw-normal">Specialty 15</h4>
                </div>
                <div class="card-body">
                    <h1 class="card-title">Porksilog</h1>
                    <ul class="list-unstyled mt-3 mb-4">
                        <li><img src="Pork.jpg" alt="eggtart" style="width:70%;height:250px;"></li>
                        <li>Price: ₱95.00</li>
                    </ul>
                    <form action="addCart.php" method="post">
                        <input type="hidden" name="name" value="Porksilog">
                        <input type="hidden" name="price" value="95.00">
                        <input type="text" name="qty" placeholder="Quantity" required class="form-control">
                        <input type="submit" class="btn btn-lg btn-primary" value="Add to Cart">
                    </form>
                </div>
                </div>
            </div>

            <div class="col">
                <div class="card mb-4 rounded-3 shadow-sm">
                <div class="card-header py-3">
                    <h4 class="my-0 fw-normal">Specialty 16</h4>
                </div>
                <div class="card-body">
                    <h1 class="card-title">Tapa-Queensilog</h1>
                    <ul class="list-unstyled mt-3 mb-4">
                        <li><img src="Tapa-Queen.jpg" alt="eggtart" style="width:70%;height:250px;"></li>
                        <li>Price: ₱99.00</li>
                    </ul>
                    <form action="addCart.php" method="post">
                        <input type="hidden" name="name" value="Tapa-Queensilog">
                        <input type="hidden" name="price" value="99.00">
                        <input type="text" name="qty" placeholder="Quantity" required class="form-control">
                        <input type="submit" class="btn btn-lg btn-primary" value="Add to Cart">
                    </form>
                </div>
                </div>
            </div>

            <div class="col">
                <div class="card mb-4 rounded-3 shadow-sm">
                <div class="card-header py-3">
                    <h4 class="my-0 fw-normal">Specialty 17</h4>
                </div>
                <div class="card-body">
                    <h1 class="card-title">Fried Tilapia</h1>
                    <ul class="list-unstyled mt-3 mb-4">
                        <li><img src="TIlapia.jpg" alt="eggtart" style="width:70%;height:250px;"></li>
                        <li>Price: ₱90.00</li>
                    </ul>
                    <form action="addCart.php" method="post">
                        <input type="hidden" name="name" value="Fried Tilapia">
                        <input type="hidden" name="price" value="90.00">
                        <input type="text" name="qty" placeholder="Quantity" required class="form-control">
                        <input type="submit" class="btn btn-lg btn-primary" value="Add to Cart">
                    </form>
                </div>
                </div>
            </div>

            <div class="col">
                <div class="card mb-4 rounded-3 shadow-sm">
                <div class="card-header py-3">
                    <h4 class="my-0 fw-normal">Specialty 18</h4>
                </div>
                <div class="card-body">
                    <h1 class="card-title">Tocinosilog</h1>
                    <ul class="list-unstyled mt-3 mb-4">
                        <li><img src="Tocino.jpg" alt="eggtart" style="width:70%;height:250px;"></li>
                        <li>Price: ₱99.00</li>
                    </ul>
                    <form action="addCart.php" method="post">
                        <input type="hidden" name="name" value="Tocinosilog">
                        <input type="hidden" name="price" value="99.00">
                        <input type="text" name="qty" placeholder="Quantity" required class="form-control">
                        <input type="submit" class="btn btn-lg btn-primary" value="Add to Cart">
                    </form>
                </div>
                </div>
            </div>
            </div>
        </main>
    </div>
</body>
</html>